// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// config
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of window_size
//        bit 31~0 - window_size[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of window_offset
//        bit 31~0 - window_offset[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of scaling_factor
//        bit 31~0 - scaling_factor[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of out_reset
//        bit 31~0 - out_reset[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of out_offset
//        bit 31~0 - out_offset[31:0] (Read)
// 0x34 : Control signal of out_offset
//        bit 0  - out_offset_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNN_AXI_CONFIG_ADDR_WINDOW_SIZE_DATA    0x10
#define XNN_AXI_CONFIG_BITS_WINDOW_SIZE_DATA    32
#define XNN_AXI_CONFIG_ADDR_WINDOW_OFFSET_DATA  0x18
#define XNN_AXI_CONFIG_BITS_WINDOW_OFFSET_DATA  32
#define XNN_AXI_CONFIG_ADDR_SCALING_FACTOR_DATA 0x20
#define XNN_AXI_CONFIG_BITS_SCALING_FACTOR_DATA 32
#define XNN_AXI_CONFIG_ADDR_OUT_RESET_DATA      0x28
#define XNN_AXI_CONFIG_BITS_OUT_RESET_DATA      32
#define XNN_AXI_CONFIG_ADDR_OUT_OFFSET_DATA     0x30
#define XNN_AXI_CONFIG_BITS_OUT_OFFSET_DATA     32
#define XNN_AXI_CONFIG_ADDR_OUT_OFFSET_CTRL     0x34

