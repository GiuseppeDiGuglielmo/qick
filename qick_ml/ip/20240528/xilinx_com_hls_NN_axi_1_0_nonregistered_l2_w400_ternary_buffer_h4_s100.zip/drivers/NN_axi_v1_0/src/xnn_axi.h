// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XNN_AXI_H
#define XNN_AXI_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xnn_axi_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Config_BaseAddress;
} XNn_axi_Config;
#endif

typedef struct {
    u32 Config_BaseAddress;
    u32 IsReady;
} XNn_axi;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XNn_axi_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XNn_axi_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XNn_axi_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XNn_axi_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XNn_axi_Initialize(XNn_axi *InstancePtr, u16 DeviceId);
XNn_axi_Config* XNn_axi_LookupConfig(u16 DeviceId);
int XNn_axi_CfgInitialize(XNn_axi *InstancePtr, XNn_axi_Config *ConfigPtr);
#else
int XNn_axi_Initialize(XNn_axi *InstancePtr, const char* InstanceName);
int XNn_axi_Release(XNn_axi *InstancePtr);
#endif


void XNn_axi_Set_window_size(XNn_axi *InstancePtr, u32 Data);
u32 XNn_axi_Get_window_size(XNn_axi *InstancePtr);
void XNn_axi_Set_window_offset(XNn_axi *InstancePtr, u32 Data);
u32 XNn_axi_Get_window_offset(XNn_axi *InstancePtr);
void XNn_axi_Set_scaling_factor(XNn_axi *InstancePtr, u32 Data);
u32 XNn_axi_Get_scaling_factor(XNn_axi *InstancePtr);
void XNn_axi_Set_out_reset(XNn_axi *InstancePtr, u32 Data);
u32 XNn_axi_Get_out_reset(XNn_axi *InstancePtr);
u32 XNn_axi_Get_out_offset(XNn_axi *InstancePtr);
u32 XNn_axi_Get_out_offset_vld(XNn_axi *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
