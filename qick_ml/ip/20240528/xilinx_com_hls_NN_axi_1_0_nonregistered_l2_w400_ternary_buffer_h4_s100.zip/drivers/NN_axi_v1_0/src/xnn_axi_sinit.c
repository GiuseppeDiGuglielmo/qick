// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xnn_axi.h"

extern XNn_axi_Config XNn_axi_ConfigTable[];

XNn_axi_Config *XNn_axi_LookupConfig(u16 DeviceId) {
	XNn_axi_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XNN_AXI_NUM_INSTANCES; Index++) {
		if (XNn_axi_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XNn_axi_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XNn_axi_Initialize(XNn_axi *InstancePtr, u16 DeviceId) {
	XNn_axi_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XNn_axi_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XNn_axi_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

