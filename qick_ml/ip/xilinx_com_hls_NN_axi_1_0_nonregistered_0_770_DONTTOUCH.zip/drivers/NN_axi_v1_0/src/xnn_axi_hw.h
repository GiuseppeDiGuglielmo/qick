// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// config
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of scaler
//        bit 31~0 - scaler[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of trigger_delay
//        bit 31~0 - trigger_delay[31:0] (Read/Write)
// 0x1c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNN_AXI_CONFIG_ADDR_SCALER_DATA        0x10
#define XNN_AXI_CONFIG_BITS_SCALER_DATA        32
#define XNN_AXI_CONFIG_ADDR_TRIGGER_DELAY_DATA 0x18
#define XNN_AXI_CONFIG_BITS_TRIGGER_DELAY_DATA 32

