// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xnn_axi.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XNn_axi_CfgInitialize(XNn_axi *InstancePtr, XNn_axi_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Config_BaseAddress = ConfigPtr->Config_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

u32 XNn_axi_Get_config_r_BaseAddress(XNn_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Config_BaseAddress + XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE);
}

u32 XNn_axi_Get_config_r_HighAddress(XNn_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Config_BaseAddress + XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH);
}

u32 XNn_axi_Get_config_r_TotalBytes(XNn_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH - XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + 1);
}

u32 XNn_axi_Get_config_r_BitWidth(XNn_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNN_AXI_CONFIG_WIDTH_CONFIG_R;
}

u32 XNn_axi_Get_config_r_Depth(XNn_axi *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XNN_AXI_CONFIG_DEPTH_CONFIG_R;
}

u32 XNn_axi_Write_config_r_Words(XNn_axi *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH - XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Config_BaseAddress + XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XNn_axi_Read_config_r_Words(XNn_axi *InstancePtr, int offset, int *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH - XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Config_BaseAddress + XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + (offset + i)*4);
    }
    return length;
}

u32 XNn_axi_Write_config_r_Bytes(XNn_axi *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH - XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Config_BaseAddress + XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XNn_axi_Read_config_r_Bytes(XNn_axi *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH - XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Config_BaseAddress + XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE + offset + i);
    }
    return length;
}

