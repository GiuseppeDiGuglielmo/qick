// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// config
// 0x10 ~
// 0x17 : Memory 'config_r' (2 * 32b)
//        Word n : bit [31:0] - config_r[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XNN_AXI_CONFIG_ADDR_CONFIG_R_BASE 0x10
#define XNN_AXI_CONFIG_ADDR_CONFIG_R_HIGH 0x17
#define XNN_AXI_CONFIG_WIDTH_CONFIG_R     32
#define XNN_AXI_CONFIG_DEPTH_CONFIG_R     2

